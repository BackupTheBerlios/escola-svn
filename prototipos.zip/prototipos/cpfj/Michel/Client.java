import javax.ejb.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import java.rmi.RemoteException;
import javax.rmi.PortableRemoteObject;
import java.util.Enumeration;

public class Client
{
   public static void main (String args[]) 
   {
     try { 
 	       Context initial = new InitialContext();
	       Object objref = initial.lookup ("TheCCPFJ");
           CCPFJHome home = (CCPFJHome) PortableRemoteObject.narrow (objref,CCPFJHome.class);
	       CCPFJ ccpfj = home.create();
           
           System.out.println("Add -> Michel,860303101-00, 4312462");
           PessoaFisica pf = new PessoaFisica("Michel","860303101-00","4312462");
           ccpfj.addPessoaFisica(pf);
           
           System.out.println("Add -> Coca-Cola Company, Coca-Cola, 4568723464");
           PessoaJuridica pj = new PessoaJuridica("Coca-Cola Company","Coca-Cola","4568723464");
           ccpfj.addPessoaJuridica(pj);
           
     } 
     catch (Exception ex) {  	 		
	       System.out.println(ex.getMessage());
	 }
   }
}	     	
