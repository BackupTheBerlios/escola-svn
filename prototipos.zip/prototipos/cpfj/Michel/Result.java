 /**
   * Esta classe encapsula informacoes sobre o resultado de uma busca
   * por todas as pessoas cadastradas pelo componente. Por motivos de
   * desempenho, esta classe informa ao cliente a quantidade de
   * ocorrencias ou pessoas que estao cadastradas, a posicao inicial de
   * busca ou leitura.
   * @see java.lang.Object
   * @author Michel Mitsunaga
   */


public class Result
{
    String teste [] ={"teste","teste"};
	// informacao sobre a quantidade de ocorrencias
	private int qtde;
	// informa sobre a posicao de inicio
	private int start;
    
    /** 
      * Este � o construtor padr�o da classe Result.
      * Inicializa os campos da classe com valores apropriados.
    */
    public Result (){};
    
    /**
      * Este m�todo obt�m a quantidade de valores retornados.
      * @return <code> int </code>
      */
    public int getQuantity() { return qtde;}
    
    /**
      * Este m�todo obt�m a posi��o inicial da pr�xima busca.
      * @return <code> int </code>
      */
    public int getStartPos() {return start;}

    /**
      * Este m�todo configura a quantidade o valor da quantidade retornada.
      * @param q especifica a nova quantidade.
      */
    public void setQuantity(int q) {};
    
    /**
      * Este m�todo configura a posi��o inicial da pr�xima busca.
      * @param s especifica a nova posi��o inicial.
      */
    public void setStartPos(int s) {};

    /**
      * Este m�todo obt�m os elementos da consulta, de acordo com a posi��o inicial e sua quantidade.
      * @param qtde especifica a quantidade total de elementos que satisfa�am a busca.
      * @param start especifica a posi��o inicial que deve-se buscar tais elementos.
      * @return <code> object </code>
      */
   public Object[] getElements(int qtde, int start) {return teste;}

}

	
