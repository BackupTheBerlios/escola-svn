import java.util.Enumeration;
import java.util.Vector;

public class Tel
{
   private int codPais;
   private int DDD;			//PK
   private int ramal;
   private String numero;   //PK
   
   private String [] Atributos = {"Codigo", "DDD", "Ramal", "Numero"};
   
   
   public Tel() {
      this.codPais = 0;
      this.DDD = 62;
      this.ramal = 0;
      this.numero = "";     
   }
   
   public Tel (int codPais, int DDD, int ramal, String n)
   {
      this.codPais = codPais;
      this.DDD = DDD;
      this.ramal = ramal;
      this.numero = n;     
   }
   
   public void set(String attr, Object value) throws Exception
   {
   	 
   	 
   	 if (attr.equals("Codigo")) {
   	    Integer cod = (Integer) value;
   	    this.codPais = cod.intValue();
   	 }   
   	 else if (attr.equals("DDD")){
   	    Integer ddd = (Integer) value;
        this.DDD = ddd.intValue();
     }   
   	 else if (attr.equals("Ramal")){
        Integer ram = (Integer) value;
        this.ramal = ram.intValue();
     }   
   	 else if (attr.equals("Numero"))
   	         this.numero = (String) value;
   	 else 
   	      throw new Exception("Atributo Desconhecido");
   }	                          
   	 
   	 
   public Object get (String attr) throws Exception
   {
      if (attr.equals("Codigo")){
    	Integer cod = new Integer (this.codPais); 
   	    return (Object)cod;
   	  }    
   	  else if (attr.equals("DDD")){
   	    Integer ddd = new Integer (this.DDD);
        return (Object) ddd;
      }   
   	  else if (attr.equals("Ramal")){
        Integer ram = new Integer(this.ramal);
        return (Object) ram;     
      }   
   	  else if (attr.equals("Numero"))
   	    return (Object) this.numero;
      else throw new Exception("Atributo Desconhecido");
   }
   
   
   
   public Vector getListAtributes() 
   {
   	 Vector v = new Vector(); 
   	 for (int i = 0; i < Atributos.length;i++)
	   v.add(Atributos[i]);
	 return v;   
   }

  public static void main (String args[])
  {
  	
  	Tel t = new Tel(51,62,0,"286-34-92");
  	Vector a = t.getListAtributes();
  	
  	
  	System.out.println("Lista de atributos");
  	
  	try {
  		
  	for (int i = 0; i < a.size(); i++)   	   
  	   System.out.println(a.get(i)+": " + t.get( (String) a.get(i) ) );
    
    
    //System.out.println (t.get("Mcek"));
    t.set("Numero","233-9363");
    
    
    Integer x = new Integer(34);
    t.set("Codigo",(Object) x);
    
    for (int i = 0; i < a.size(); i++)   	   
  	   System.out.println(a.get(i)+": " + t.get( (String) a.get(i) ) );
    
           
    } catch (Exception e){
    	String message = e.getMessage();
    	System.out.println(message);
    }	      
    
  }


}
   
