import java.util.Vector;

/** 
  * Esta classe encapsula informa��es sobre PessoaJuridica.
  * @see java.lang.Object
  * @author Michel Mitsunaga
  */

public class PessoaJuridica
{
	private String CNPJ;
	private String razaoSocial;
	private String nomeFantasia;
    private String atividade;
    private String inscrEstadual;
    private String inscrMunicipal;
    private String home;
    private String email;
    private Vector listEnder  = new Vector();
    private Vector listTel =  new Vector();
    
    private static String Atributos[] = {"CNPJ", "RazaoSocial", "NomeFantasia",
    								   "Atividade", "InscrEstadual", "InscrMunicipal",
    								   "Home","Email","ListEnderecos","ListTelefones"};
    
    /** 
    * Este � o construtor da classe PessoaJuridica.
    * Inicializa os campos da classe com valores apropriados.
    */
   	public PessoaJuridica()
   	{
   	   this.CNPJ = "";
   	   this.razaoSocial = "";
   	   this.nomeFantasia = "";
   	   this.atividade = "";
   	   this.inscrEstadual = "";
   	   this.inscrMunicipal = "";
   	   this.home = "";
   	   this.email = "";
   	}
   	
   	/** 
    * Este � o construtor da classe PessoaJuridica.
    * Inicializa os campos da classe com valores apropriados.
    * @param CNPJ especifica o n� de CNPJ.
    * @param razaoSocial especifica a razao social.
    * @param nomeFantasia especifica o nome fantasia.
    * @param inscrEstadual especifica o n� da inscri��o estadual.
    * @param inscrMunicipal especifica o n� da inscri��o estadual.
    * @see java.lang.String.
    */
    public PessoaJuridica (String CNPJ, String razao, String fantasia)
    {
    	this.CNPJ = CNPJ;
   	    this.razaoSocial = razao;
   	    this.nomeFantasia = fantasia;
   	}   					  
    					    	
     
     /**
     * Retorna ao usu�rio a lista de atributos da classe. Isto � necess�rio
     * para que o uso dos demais m�todos da classe sejam utilizados corretamente,
     * visto q o nome do atributo deve ser corretamente fornecido. 
     * @return Enumeration.
     * @see java.util.Enumeration.
     */
     public Vector getListAtributes()
     {
     	Vector v = new Vector(); 
   	    for (int i = 0; i < Atributos.length;i++)
	       v.add(Atributos[i]);
	    return v;   
     }
    
    
    /**
    * Configura algum atributo da classe Endereco.
    * Recebe como par�metro o nome do atributo a ser modificado e seu valor.
    * @param attr especifica qual o atributo que ser� modificado.
    * @param value especifica o novo valor do atributo.
    * @return retorna null
    * @see java.lang.String.
    * @see java.lang.Object.
    */
    public void set (String attr, Object value) throws Exception
    {
       if (attr.equals("CNPJ"))
   	       this.CNPJ = (String) value;
   	   else if (attr.equals("RazaoSocial"))
   	       this.razaoSocial = (String) value;
   	   else if (attr.equals("NomeFantasia"))
   	       this.nomeFantasia = (String) value;
   	   else if (attr.equals("Atividade"))
   	       this.atividade = (String) value;
   	   else if (attr.equals("InscrEstadual"))
   	       this.inscrEstadual = (String) value;
   	   else if (attr.equals("InscrMunicipal"))
   	       this.inscrMunicipal = (String) value;
   	   else if (attr.equals("Home"))
   	       this.home = (String) value;
   	   else if (attr.equals("Email"))
   	       this.email = (String) value;
   	   else if (attr.equals("ListEnderecos"))     //Insere no Vector cada Objeto Ender
   	       this.listEnder.add( (Ender) value);
   	   else if (attr.equals("LisTelefones"))
   	       this.listTel.add( (Tel) value);
   	   else 
   	       throw new Exception ("Atributo Desconhecido.");
   	 }
   	       
    
    
    
    /**
    * Obtem o valor de algum atributo da classe PessoaFisica.
    * Recebe como par�metro o nome do atributo desejado.
    * @param attr especifica qual o atributo desejado.
    * @return um <code> object </code> � retornado. 
    * @see java.lang.String.
    * @see java.lang.Object.
    */
    public Object get (String attr) throws Exception 
    {
        if (attr.equals("CNPJ"))
   	       return (Object) this.CNPJ;
   	    else if (attr.equals("RazaoSocial"))
   	       return (Object) this.razaoSocial;
   	    else if (attr.equals("NomeFantasia"))
   	       return (Object) this.nomeFantasia;
   	    else if (attr.equals("Atividade"))
   	       return (Object) this.atividade;
   	    else if (attr.equals("InscrEstadual"))
   	       return (Object) this.inscrEstadual;
   	    else if (attr.equals("InscrMunicipal"))
   	       return (Object) this.inscrMunicipal;
   	    else if (attr.equals("Home"))
   	       return (Object) this.home;
   	    else if (attr.equals("Email"))
   	       return (Object) this.email;
   	    else if (attr.equals("ListEnderecos"))      // retorna o Vector
   	       return (Object) this.listEnder;        
   	    else if (attr.equals("LisTelefones"))
   	       return (Object) this.listTel;
   	    else 
   	       throw new Exception ("Atributo Desconhecido.");   
    
    	
    }	
}
