import javax.ejb.*;
import java.rmi.RemoteException;


public interface CCPFJHome extends EJBHome
{
	
	public CCPFJ create () throws RemoteException, CreateException;

}
	
