import javax.ejb.*;
import java.rmi.RemoteException;
import java.util.Enumeration;

public interface CCPFJ extends EJBObject
{
	  // adiciona uma pessoa fisica e retorna o handle correspondente
      // Caso exista a pessoa, retorna NULL.
      public PFisHandle addPessoaFisica (PessoaFisica p) throws RemoteException;
      
      //adiciona uma pessoa juridica e retorna o handle correspondente
      // Caso exista a pessoa, retorna NULL.
      public PJurHandle addPessoaJuridica (PessoaJuridica p) throws RemoteException;
      
	  public boolean deletePessoaFisica (PFisHandle id) throws RemoteException;

      /* Remove uma Pessoa Juridica atraves de seu Handle. 
      Retorna true se operacao concluida com sucesso.
      Caso Contrario, retorna falso. */
      public boolean deletePessoaJuridica (PJurHandle id) throws RemoteException;

	  /* Atualiza uma Pessoa Fisica atraves de seu Handle e dados 
         Retorna true se operacao concluida com sucesso.
         Caso Contrario, retorna falso. */
      public boolean updatePessoaFisica (PFisHandle id, PessoaFisica dados) throws RemoteException;
      
      /* Atualiza uma Pessoa Fisica atraves de seu Handle e dados 
         Retorna true se operacao concluida com sucesso.
         Caso Contrario, retorna falso. */
      public boolean updatePessoaJuridica (PJurHandle id, PessoaJuridica dados) throws RemoteException;
	  
	  // Retorna o Handle da Pessoa Fisica atraves de seu cpf
      public PFisHandle getHandlePessoaFisica (String cpf) throws RemoteException;
      
      // Retorna o Handle da Pessoa Juridica atraves de seu cpf
      public PJurHandle getHandlePessoaJuridica (String cnpj) throws RemoteException;
		
       
      public PessoaFisica findByHandlePessoaFisica(PFisHandle id) throws RemoteException;
      public PessoaJuridica findByHandlePessoaJuridica(PJurHandle id) throws RemoteException;
      
      public Enumeration findByQueryPessoaFisica(Consult c) throws RemoteException;
      public Enumeration findByQueryPessoaJuridica(Consult c) throws RemoteException;
    
      //public Result findByQueryPessoaFisica(Consult c) throws RemoteException;
      //public Result findByQueryPessoaJuridica(Consult c) throws RemoteException;
      //public void buildBaseline (String nomeBaseLine) throws RemoteException;
      //public void restoreBaseline (String nomeBaseLine) throws RemoteException;
}      
      
