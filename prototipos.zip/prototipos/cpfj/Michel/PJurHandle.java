

import java.io.Serializable;

public class PJurHandle implements Serializable

{
	//int handle;
	private String cnpj;
	
	public PJurHandle() {}
	
	public PJurHandle(String cnpj)
	{
		this.cnpj = cnpj;
	}
	
	public String toString ()
	{
		return this.cnpj;
	}

}
