import java.util.Vector;

public class Ender
{
    private int numero;
    private String CEP;
    private String logradouro;
    private String complemento;
    private String bairro;
    private String cidade;
    private String pais;
    private String UF;
    
    private String [] Atributos = {"CEP","Numero","Logradouro",
    							   "Complemento","Bairro","Cidade","UF","Pais"};
    							   
    
    public Ender () 
    {
      this.numero = 0;
      this.CEP = "";
      this.logradouro = "";
      this.complemento = "";
      this.bairro = "";
      this.cidade = "";
      this.pais = "";
      this.UF = "";
    } 
    
   public Ender (int num, String cep, String log, 
                 String comp, String b, String c, String uf, String p)
   {              
   
     this.numero = num;
     this.CEP = cep;
     this.logradouro = log;
     this.complemento = comp;
     this.bairro = b;
     this.cidade = c;
     this.UF = uf;
     this.pais = p;
  }   
    
    public String getCEP() {
        return this.CEP;	
    }
    
    public int getNumero() {
    	return this.numero;
    }
    
    public void setCEP(String nCEP) {
    	this.CEP = nCEP;
    }
    
    public void setNumero(int n) {
    	this.numero = n;
    }
    
    
    
    public Vector getListAtributes()
    {
    	Vector v = new Vector(); 
   	    for (int i = 0; i < Atributos.length;i++)
	      v.add(Atributos[i]);
	    return v;
	} 
	
    
    public void set (String attr, Object value) throws Exception
    {
      if (attr.equals("Numero")){
      	Integer num = (Integer) value;
   	    this.numero = num.intValue();
   	  }       
   	  else if (attr.equals("CEP"))
   	         this.CEP = (String) value; 
   	  else if (attr.equals("Logradouro"))
   	         this.logradouro = (String) value; 
   	  else if (attr.equals("Complemento"))
   	         this.complemento = (String) value; 
   	  else if (attr.equals("Bairro"))
   	         this.bairro = (String) value; 
   	  else if (attr.equals("Cidade"))
   	         this.cidade = (String) value; 
   	  else if (attr.equals("UF"))
   	         this.UF = (String) value; 
   	  else if (attr.equals("Pais"))
   	         this.pais = (String) value; 
   	  else
   	       throw new Exception("Atributo Desconhecido");	
   }   
   
   public Object get (String attr) throws Exception
   {
   	  if (attr.equals("Numero")){
    	Integer num = new Integer (this.numero); 
   	    return (Object)num;
   	  }    
   	  else if (attr.equals("CEP"))
   	    return (Object) this.CEP;
      else if (attr.equals("Logradouro"))
   	    return (Object) this.logradouro;
      else if (attr.equals("Complemento"))
   	    return (Object) this.complemento;
      else if (attr.equals("Bairro"))
   	    return (Object) this.bairro;
      else if (attr.equals("Cidade"))
   	    return (Object) this.cidade;
   	  else if (attr.equals("UF"))
   	    return (Object) this.UF;
      else if (attr.equals("Pais"))
   	    return (Object) this.pais;
      else 
        throw new Exception("Atributo Desconhecido"); 
   }   



}

