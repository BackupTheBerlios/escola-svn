import java.io.Serializable;

public class PFisHandle implements Serializable

{
	//int handle;
	private String cpf;
	
	public PFisHandle() {}
	
	public PFisHandle(String cpf)
	{
		this.cpf = cpf;
	}
	
	public String toString ()
	{
		return this.cpf;
	}

}

