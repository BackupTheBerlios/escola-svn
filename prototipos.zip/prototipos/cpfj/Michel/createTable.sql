create table PessoaFisica
(
  nome varchar (80) NOT NULL,
  cpf  varchar (13) NOT NULL,
  rg   varchar (20) NOT NULL,
  primary key (cpf)
);

create table PessoaJuridica
(
  razao     varchar (30) NOT NULL,
  fantasia  varchar (30) NOT NULL,
  cnpj      varchar (20) NOT NULL,
  primary key (cnpj)
);

create table EnderPFisica 
(
  cpfPessoa    varchar (13) NOT NULL,
  num    int
  cep    varchar (10) NOT NULL,
  log    varchar (50),
  comp   varchar (20),
  bairro varchar (20),
  cidade varchar (20),
  UF     char (2),
  pais   varchar(20),
  primary key (cpfPessoa,cep),
  foreign key (cpfPessoa) references PessoaFisica(cpf)
);

create table EnderPFisica 
(
  cnpjPessoa    varchar (20) NOT NULL,
  num    int,
  cep    varchar (10) NOT NULL,
  log    varchar (50),
  comp   varchar (20),
  bairro varchar (20),
  cidade varchar (20),
  UF     char (2),
  pais   varchar(20),
  primary key (cnpjPessoa,cep),
  foreign key (cnpjPessoa) references PessoaJuridica(cnpj)
);

create table TelPFisica
(
  cpfPessoa    varchar (13) NOT NULL,
  DDD		   int NOT NULL,
  num          varchar (10) NOT NULL,
  ramal        int,
  codPais      int,
  primary key (cpfPessoa, DDD, num),
  foreign key (cpfPessoa) references PessoaFisica (cpf)
);

create table TelPJuridica
(
  cnpjPessoa    varchar (20) NOT NULL,
  DDD		   int NOT NULL,
  num          varchar (10) NOT NULL,
  ramal        int,
  codPais      int,
  primary key (cnpjPessoa, DDD, num),
  foreign key (cnpjPessoa) references PessoaJuridica (cnpj)
);  
exit;
