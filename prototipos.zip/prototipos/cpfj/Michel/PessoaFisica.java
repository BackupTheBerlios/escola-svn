import java.util.Vector;


/** 
  * Esta classe encapsula informa��es sobre PessoaFisica.
  * @see java.lang.Object
  * @author Michel Mitsunaga
  */
public class PessoaFisica 
{
	
	
	private String CPF;				
	private String nome;		    
	private String dataNascimento;
	private String nacionalidade;
	private String naturalidade;
	private String estado;
	private String nomePai;
	private String nomeMae;
	private String sexo;	          
	private String email;
    private String RG;            
    private String orgaoExp;      
    private String emissaoRG;
    private String nTituloE;
    private int secao;
    private int zona;
    private String municipio;
    private String emissaoTitE;
    private String docMilitar;   	
   	private String passport;
   	private Vector listEnder;
   	private Vector listTel;
   	
   	private String Atributos[] = {"CPF","Nome","DataNascimento","Nacionalidade",
   	                              "Naturalidade","Estado","NomePai","NomeMae",
   	                              "Sexo","Email","RG","OrgaoExpRG","DataEmissaoRG",
   	                              "NumTitulo","Secao","Zona","MunicipioTitulo",
   	                              "DataEmissaoTitulo","DocMilitar","Passport",
   	                              "ListEnderecos","ListTelefones"};
   	
   	/** 
    * Este � o construtor da classe PessoaFisica.
    * Inicializa os campos da classe com valores apropriados.
    */
   	public PessoaFisica()
   	{
   	   this.CPF = "";				
	   this.nome = "";
	   this.dataNascimento = "";
	   this.nacionalidade ="";
	   this.naturalidade = "";
	   this.estado = "";
	   this.nomePai = "";
	   this.nomeMae = "";
	   this.sexo = "";	          
	   this.email ="";
       this.RG = "";            
       this.orgaoExp = "";      
       this.emissaoRG = "";
       this.nTituloE = "";
       this.secao = 0;
       this.zona = 0;
       this.municipio = "";
       this.emissaoTitE = "";
       this.docMilitar = "";
   	   this.passport = "";
   	   this.listEnder =  new Vector();
   	   this.listTel =  new Vector();
   	}
   	
   	/** 
    * Este � o construtor da classe PessoaFisica.
    * Inicializa os campos da classe com valores apropriados.
    * @param nome especifica o nome completo da PessoaFisica.
    * @param CPF especifica o n� de Cadastro de Pessoa Fisica (CPF). 
    * @param RG especifica o n� de Registro Geral (RG) da PessoaFisica.
    * @see java.lang.String.
    */
   	public PessoaFisica (String nome, String CPF, String RG) 
   	{
   	   this.CPF = CPF;				
	   this.nome = nome;
	   this.RG = RG;            
    }
   	
   	
   	/**
     * Retorna ao usu�rio a lista de atributos da classe. Isto � necess�rio
     * para que o uso dos demais m�todos da classe sejam utilizados corretamente,
     * visto q o nome do atributo deve ser corretamente fornecido. 
     * @return Enumeration.
     * @see java.util.Enumeration.
     */
    
    public Vector getListAtributes()
    {
      Vector v = new Vector(); 
   	  for (int i = 0; i < Atributos.length;i++)
	     v.add(Atributos[i]);
	  return v;	
     }
    
   	/**
    * Configura algum atributo da classe Endereco.
    * Recebe como par�metro o nome do atributo a ser modificado e seu valor.
    * @param attr especifica qual o atributo que ser� modificado.
    * @param value especifica o novo valor do atributo.
    * @return retorna null
    * @see java.lang.String.
    * @see java.lang.Object.
    */
    
    
   	public void set (String attr, Object value) throws Exception
   	{
   	   if (attr.equals("CPF"))
   	       this.CPF = (String) value;
   	   else if (attr.equals("Nome"))
   	       this.nome = (String) value;
   	   else if (attr.equals("DataNascimento"))
   	       this.dataNascimento = (String) value;
   	   else if (attr.equals("Nacionalidade"))
   	       this.nacionalidade = (String) value;
   	   else if (attr.equals("Naturalidade"))
   	       this.naturalidade = (String) value;
   	   else if (attr.equals("Estado"))
   	       this.estado = (String) value;
   	   else if (attr.equals("NomePai"))
   	       this.nomePai = (String) value;
   	   else if (attr.equals("NomeMae"))
   	       this.nomeMae = (String) value;
   	   else if (attr.equals("Sexo"))
   	       this.sexo = (String) value;
   	   else if (attr.equals("RG"))
   	       this.RG = (String) value;
   	   else if (attr.equals("OrgaoExpRG"))
   	       this.orgaoExp = (String) value;
   	   else if (attr.equals("DataEmissaoRG"))
   	       this.emissaoRG = (String) value;
   	   else if (attr.equals("NumTitulo"))
   	       this.nTituloE = (String) value;
   	   else if (attr.equals("Secao")){
   	        Integer sec = (Integer) value;
   	        this.secao = sec.intValue();
   	   }    
   	   else if (attr.equals("Zona")){
   	   	    Integer z = (Integer) value;
   	        this.zona = z.intValue();
       }    
   	   else if (attr.equals("MunicipioTitulo"))
   	       this.municipio = (String) value;
   	   else if (attr.equals("DataEmissaoTitulo"))
   	       this.emissaoTitE = (String) value;
   	   else if (attr.equals("DocMilitar"))
   	       this.docMilitar = (String) value;
   	   else if (attr.equals("Passport"))
   	       this.passport = (String) value;
   	   else if (attr.equals("ListEnderecos"))     //Insere no Vector cada Objeto Ender
   	       this.listEnder.add( (Ender) value);
   	   else if (attr.equals("LisTelefones"))
   	       this.listTel.add( (Tel) value);
   	   else 
   	       throw new Exception ("Atributo Desconhecido.");
   	
   	}
    
    
    /**
    * Obtem o valor de algum atributo da classe PessoaFisica.
    * Recebe como par�metro o nome do atributo desejado.
    * @param attr especifica qual o atributo desejado.
    * @return um <code> object </code> � retornado. 
    * @see java.lang.String.
    * @see java.lang.Object.
    */
    public Object get (String attr) throws Exception
    {
      if (attr.equals("CPF"))
   	       return (Object) this.CPF;
   	   else if (attr.equals("Nome"))
   	       return (Object) this.nome;
   	   else if (attr.equals("DataNascimento"))
   	       return (Object) this.dataNascimento;
   	   else if (attr.equals("Nacionalidade"))
   	       return (Object) this.nacionalidade;
   	   else if (attr.equals("Naturalidade"))
   	       return (Object) this.naturalidade;
   	   else if (attr.equals("Estado"))
   	       return (Object) this.estado;
   	   else if (attr.equals("NomePai"))
   	       return (Object) this.nomePai;
   	   else if (attr.equals("NomeMae"))
   	       return (Object) this.nomeMae;
   	   else if (attr.equals("Sexo"))
   	       return (Object) this.sexo;
   	   else if (attr.equals("RG"))
   	       return (Object) this.RG;
   	   else if (attr.equals("OrgaoExpRG"))
   	       return (Object) this.orgaoExp;
   	   else if (attr.equals("DataEmissaoRG"))
   	       return (Object) this.emissaoRG;
   	   else if (attr.equals("NumTitulo"))
   	       return (Object) this.nTituloE;
   	   else if (attr.equals("Secao")){
   	        Integer s = new Integer(this.secao);
   	        return (Object) s;
   	   }    
   	   else if (attr.equals("Zona")){
   	   	    Integer z = new Integer(this.zona);
   	        return (Object) z;
       }    
   	   else if (attr.equals("MunicipioTitulo"))
   	       return (Object) this.municipio;
   	   else if (attr.equals("DataEmissaoTitulo"))
   	       return (Object) this.emissaoTitE;
   	   else if (attr.equals("DocMilitar"))
   	       return (Object) this.docMilitar;
   	   else if (attr.equals("Passport"))
   	       return (Object) this.passport;
   	   else if (attr.equals("ListEnderecos"))     //Insere no Vector cada Objeto Ender
   	       return (Object) this.listEnder;
   	   else if (attr.equals("LisTelefones"))
   	       return (Object) this.listTel;
   	   else 
   	       throw new Exception ("Atributo Desconhecido.");
   	
   	}	
      

}
