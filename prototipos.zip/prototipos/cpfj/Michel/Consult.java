import java.util.Hashtable;
import java.util.Enumeration;

public class Consult 
{
	
	private final int Fisica = 1;
	private final int Juridica = 2;
	
	private static StringBuffer query = new StringBuffer();
	
	public Consult (int type) throws Exception
	{
       switch (type){
       	 case Fisica:    query.insert(0,"SELECT * FROM PessoaFisica WHERE ");
       	                 break; 
         case Juridica:  query.insert(0,"SELECT * FROM PessoaJuridica WHERE ");
       	                 break;
         default:        throw new Exception ("Tipo de Consulta Inv�lida");      					 
      }
    }
	
	public void addAnd()
	{
	   query.append(" AND ");	
       
     }							
	
	public void addOR()
	{
	  query.append(" OR ");
	  
	}
	
	public void addItem (String attr, String value)
	{
		query.append(attr+"="+value);
	
	}	
	
	
    public String getQuery()
	{
		return query.toString();
	}

    public static void main (String args[])
    {
      try {
              Consult c = new Consult(1);
              c.addItem("nome","Michel");
              c.addOR();
              c.addItem("cidade","Goiania");
              System.out.println(c.getQuery());
      } catch (Exception e){
      	String message = e.getMessage();
      	System.out.println(message);
      }
    }	

}



	
