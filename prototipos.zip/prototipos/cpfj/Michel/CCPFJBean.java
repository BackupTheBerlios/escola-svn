import javax.ejb.SessionBean;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.SessionContext;
import java.util.Vector;
import java.util.Enumeration;
import java.sql.*;

public class CCPFJBean implements SessionBean 
{
	private SessionContext ctx;
	private String url = "jdbc:cloudscape:rmi:PessoasDB";
    private Connection con = null;
    
    	
	/*****************************************************
	        Metodos de negocio do componente CCPFJ
	******************************************************/
	public PFisHandle addPessoaFisica (PessoaFisica p) throws RemoteException
	{
		PreparedStatement ps = null;
		try { 
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection(this.url);
              System.out.println("addPessoaFisica()");
              String query = "INSERT INTO PessoaFisica VALUES (?,?,?)";
              ps = con.prepareStatement(query);
              // atribui valores aos simbolos de interrogacoes da query
              ps.setString (1,(String) p.get("Nome") );
              ps.setString (2,(String) p.get("CPF") );
              ps.setString (3,(String) p.get("RG") );
              //executa a insercao                              
              ps.executeUpdate();
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return new PFisHandle( (String) p.get("CPF") );
     
        } catch (Exception e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException();
        }
        
     } 
	 
	 public PJurHandle addPessoaJuridica (PessoaJuridica p) throws RemoteException
	 {
        PreparedStatement ps = null;
		try { 
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection(this.url);
              System.out.println("addPessoaJuridica()");
              String query = "INSERT INTO PessoaJuridica VALUES (?,?,?)";
              ps = con.prepareStatement(query);
              // atribui valores aos simbolos de interrogacoes da query
              ps.setString (1,(String) p.get("RazaoSocial") );
              ps.setString (2,(String) p.get("NomeFantasia") );
              ps.setString (3,(String) p.get("CNPJ") );
              //executa a insercao                              
              ps.executeUpdate();
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return new PJurHandle( (String) p.get("CNPJ") );
     
        } catch (Exception e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException();
        }
        
           
     }
      
	public boolean deletePessoaFisica (PFisHandle id) throws RemoteException
	{
       PreparedStatement ps = null;
	   String pkey = id.toString();
	   try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("deletePessoaFisica()");
              String query = "DELETE FROM PessoaFisica WHERE cpf = ?";
              ps = con.prepareStatement (query);
              ps.setString (1,pkey);
              // Acionar uma exce��o se algo de errado ocorrer
              if (ps.executeUpdate() == 0) 
              	throw new RemoteException ("Nao foi poss�vel remover a Pessoa F�sica com CPF " + pkey);
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return true;
    
       } catch (SQLException e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException ("Nao foi poss�vel remover a Pessoa F�sica com CPF " + pkey);
       }
      
                    
     }		
     
     public boolean deletePessoaJuridica (PJurHandle id) throws RemoteException
     {
     	PreparedStatement ps = null;
	    String pkey = id.toString();              
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("deletePessoaJuridica()");
              String query = "DELETE FROM PessoaJuridica WHERE cnpj = ?";
              ps = con.prepareStatement (query);
              ps.setString (1,pkey);
              if (ps.executeUpdate() == 0) 
              	throw new RemoteException ("Nao foi poss�vel remover a Pessoa Jur�dica com CNPJ " + pkey);
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              
              return true;
    
        } catch (SQLException e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException ("Nao foi poss�vel remover a Pessoa Jur�dica com CNPJ " + pkey);
        }
           
     }
     	
     public boolean updatePessoaFisica (PFisHandle id, PessoaFisica dados) 
     												throws RemoteException
     {  // Usar o Handle se este nao for o CPF
        PreparedStatement ps = null;
	    String pkey = id.toString();
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("updatePessoaFisica()");
              String query = "UPDATE PessoaFisica set nome = ?, cpf = ?, rg = ? WHERE cpf = ?";
              ps = con.prepareStatement (query);
              pkey = id.toString();
              ps.setString (1,(String) dados.get("Nome"));
              ps.setString (2,(String) dados.get("CPF"));
              ps.setString (3,(String) dados.get("RG"));
              ps.setString (4,pkey);
              ps.executeUpdate(); 
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return true;
    
        } catch (Exception e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException ("Nao foi poss�vel atualizar a Pessoa F�sica com CPF " + pkey);
        }
        
     }
     
     public boolean updatePessoaJuridica (PJurHandle id, PessoaJuridica dados) 
     												 throws RemoteException
     {
       // Usar o Handle se este nao for o CPF
        PreparedStatement ps = null;
	    String pkey = id.toString();
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("updatePessoaJuridica()");
              String query = "UPDATE PessoaJuridica set razao = ?, fantasia = ?, cnpj = ? WHERE cnpj = ?";
              ps = con.prepareStatement (query);
              ps.setString (1,(String) dados.get("RazaoSocial"));
              ps.setString (2,(String) dados.get("NomeFantasia"));
              ps.setString (3,(String) dados.get("CNPJ"));
              ps.setString (4,pkey);
              ps.executeUpdate(); 
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return true;
    
        } catch (Exception e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException ("Nao foi poss�vel atualizar a Pessoa Jur�dica com CNPJ " + pkey);
        }
    }
     
    public PFisHandle getHandlePessoaFisica (String cpf) throws RemoteException
    {
        PreparedStatement ps = null;
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("getHandlePessoaFisica()");
              String query = "Select cpf FROM PessoaFisica WHERE cpf = ?";
              ps = con.prepareStatement (query);
              ResultSet rs = ps.executeQuery(); 
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              if (rs.next()){
                 String pk = rs.getString(1);
                 return new PFisHandle(pk);
              }else return null;
                
        } catch (SQLException e){
          String message = e.getMessage();
          System.out.println(message);
          throw new RemoteException ("Nao foi poss�vel encontrar uma Pessoa Fisica com o CPF " + cpf);
        }
    }
    
    public PJurHandle getHandlePessoaJuridica (String cnpj) throws RemoteException
    {
    	PreparedStatement ps = null;
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("getHandlePessoaJuridica()");
              String query = "Select cnpj FROM PessoaJuridica WHERE cnpj = ?";
              ps = con.prepareStatement (query);
              ResultSet rs = ps.executeQuery(); 
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              if (rs.next()){
                 String pk = rs.getString(1);
                 return new PJurHandle(pk);
              } else return null;  
              
        } catch (SQLException e){
            String message = e.getMessage();
            System.out.println(message);
            throw new RemoteException ("Nao foi poss�vel encontrar uma Pessoa Jur�dica com o CNPJ " + cnpj);
        }
        
    }
    
	public PessoaFisica findByHandlePessoaFisica(PFisHandle id) throws RemoteException
	{
        PreparedStatement ps = null;
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("findByHandlePessoaFisica()");
              String query = "Select * FROM PessoaFisica WHERE cpf = ?";
              ps = con.prepareStatement (query);
              String pkey = id.toString();
              ps.setString (1,pkey);
              ResultSet rs = ps.executeQuery(); 
              // Se existe uma pessoa, instanciar a classe PessoaFisica
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              if (rs.next()){
                 //Instanciar a classe PessoaFisica e obter valores do RecordSet
                 PessoaFisica pf = new PessoaFisica (rs.getString(1),rs.getString(2),rs.getString(3));
                 return pf;
              }  else return null;
        } catch (SQLException e){
           String message = e.getMessage();
           System.out.println(message);
           throw new RemoteException ("Nao foi poss�vel encontrar uma Pessoa F�sica com o handle espec�fico");
        }
        
	}   
        
     public PessoaJuridica findByHandlePessoaJuridica(PJurHandle id) throws RemoteException
     {
     	PreparedStatement ps = null;
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("findByHandlePessoaJuridica()");
              String query = "Select * FROM PessoaJuridica WHERE cnpj = ?";
              ps = con.prepareStatement (query);
              String pkey = id.toString();
              ps.setString (1,pkey);
              ResultSet rs = ps.executeQuery(); 
              // Se existe uma pessoa, instanciar a classe PessoaFisica
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              if (rs.next()){
                 //Instanciar a classe PessoaFisica e obter valores do RecordSet
                 PessoaJuridica pj = new PessoaJuridica (rs.getString(3),rs.getString(1),rs.getString(2));
                 return pj;
              }  else return null;
        } catch (SQLException e){
           String message = e.getMessage();
           System.out.println(message);
           throw new RemoteException ("Nao foi poss�vel encontrar uma Pessoa Jur�dica com o handle espec�fico");
        }
     }
    
    // Retorna uma lista de Handles das Pessoas Fisicas  
    public Enumeration findByQueryPessoaFisica(Consult c) throws RemoteException
    {
        PreparedStatement ps = null;
	    Vector pessoas = new Vector();
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("findByQueryPessoaFisica()");
              String query = c.getQuery();
              ps = con.prepareStatement (query);
              ResultSet rs = ps.executeQuery(); 
              // Percorre o ResultSet e cria os handles
              while ( rs.next() ) 
              {
                 String id = rs.getString(2); //cpf � o segundo item da tabela
                 pessoas.addElement( new PFisHandle(id) );
              }  	         
              // Se existe uma pessoa, instanciar a classe PessoaFisica
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return pessoas.elements();
                      
         } catch (Exception e){
           String message = e.getMessage();
           System.out.println(message);
           throw new RemoteException (message);
        }	
    }
    
    public Enumeration findByQueryPessoaJuridica(Consult c) throws RemoteException
    {
        PreparedStatement ps = null;
	    Vector pessoas = new Vector();
	    try {  
              // obtem uma conexao ao banco
              DriverManager.setLogStream(System.out);
              con = DriverManager.getConnection (url);
              System.out.println("findByQueryPessoaJuridica()");
              String query = c.getQuery();
              ps = con.prepareStatement (query);
              ResultSet rs = ps.executeQuery(); 
              // Percorre o ResultSet e cria os handles
              while ( rs.next() ) 
              {
                 String id = rs.getString(3); //cpf � o segundo item da tabela
                 pessoas.addElement( new PJurHandle(id) );
              }  	         
              // Se existe uma pessoa, instanciar a classe PessoaFisica
              if (ps != null) ps.close();               
              if (con!= null) con.close();
              return pessoas.elements();
                      
         } catch (Exception e){
           String message = e.getMessage();
           System.out.println(message);
           throw new RemoteException (message);
        }	
    	
    }
          												 
	/*****************************************************
            M�todos Utilizados pelo Container EJB
    ****************************************************/
    public void ejbCreate() throws RemoteException, CreateException
    {
      System.out.println("ejbCreate()");
      
      // Carrega o Driver do Banco de dados
      try {    
             Class.forName ("COM.cloudscape.core.RmiJdbcDriver");
             System.out.println("Driver JDBC do Cloudscape Encontrado");    
       
      } catch (ClassNotFoundException cnfex){
        throw new CreateException("Falha ao carregar o driver JDBC do Cloudscape.");
      }
    }
    
    public void setSessionContext(SessionContext ctx) 
    {   
    	System.out.println("setSessionContext()");
        this.ctx = ctx;
    	
    }
    public void ejbRemove() 
    {
      System.out.println("ejbRemove()");	
    }
    public void ejbActivate()
    {  
      System.out.println("ejbActivate()");	
    }
    public void ejbPassivate() 
    {
      System.out.println("ejbPassivate()");		
    }
    public void ejbLoad() 
    {
      System.out.println("ejbLoad()");	
    }
    public void ejbStore() 
    {
      System.out.println("ejbStore()");	
    }
    
}
