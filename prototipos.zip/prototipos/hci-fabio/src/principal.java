import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;

public class principal extends JApplet {
  boolean isStandalone = false;
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenu jMenu2 = new JMenu();
  JMenuItem jMenuItem2 = new JMenuItem();
  JMenuItem jMenuItem3 = new JMenuItem();
  /**Get a parameter value*/
  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  /**Construct the applet*/
  public principal() {
    setJMenuBar(jMenuBar1);

    jMenuItem1.addActionListener(
      new ActionListener() {
        public void actionPerformed( ActionEvent e )
        {
          validar_usuario o = new validar_usuario();
          o.setSize(400,300);
          o.show();
          o.dispose();
        }
      }
    );

    jMenuItem3.addActionListener(
      new ActionListener() {
        public void actionPerformed( ActionEvent e )
        {
          System.out.println("Fim selecionado");
        }
      }
    );
  }
  /**Initialize the applet*/
  public void init() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception {
    this.setSize(new Dimension(357, 268));
    this.getContentPane().setLayout(null);
    jMenu1.setText("Caixas de di�logo");
    jMenuItem1.setText("Validar usu�rio");
    jMenu2.setText("Ajuda");
    jMenuItem2.setText("Sobre");
    jMenuItem3.setText("Fim");
    jMenuBar1.add(jMenu1);
    jMenu1.add(jMenuItem1);
    jMenuBar1.add(jMenu2);
    jMenu2.add(jMenuItem2);
    jMenu2.addSeparator();
    jMenu2.add(jMenuItem3);
  }
  /**Get Applet information*/
  public String getAppletInfo() {
    return "Applet Information";
  }
  /**Get parameter info*/
  public String[][] getParameterInfo() {
    return null;
  }

  //static initializer for setting look & feel
  static {
    try {
      //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    }
    catch(Exception e) {
    }
  }

}

