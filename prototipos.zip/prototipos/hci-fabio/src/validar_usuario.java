import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class validar_usuario extends JDialog {
  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabel1 = new JLabel();
  JTextField nome = new JTextField();
  JLabel jLabel2 = new JLabel();
  JPasswordField senha = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();

  public validar_usuario(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public validar_usuario() {
    this(null, "", false);
  }
  void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    this.getContentPane().setLayout(null);
    this.setModal(true);
    this.setTitle("Valida��o de usu�rio");
    jLabel1.setText("Nome");
    jLabel1.setBounds(new Rectangle(31, 23, 34, 17));
    nome.setBounds(new Rectangle(77, 21, 107, 21));
    jLabel2.setText("Senha");
    jLabel2.setBounds(new Rectangle(29, 57, 36, 17));
    senha.setBounds(new Rectangle(76, 55, 109, 21));
    jButton1.setText("Ok");
    jButton1.setBounds(new Rectangle(152, 139, 74, 27));
    jButton2.setText("Cancela");
    jButton2.setBounds(new Rectangle(242, 139, 81, 27));
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    panel1.setBounds(new Rectangle(22, 18, 0, 0));
    getContentPane().add(panel1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(nome, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(senha, null);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }
}

