function open_disciplina()
{
 window.open("disciplina.htm","","width=700 height=500 scrollbars=yes")
}

function open_criar_usuario()
{
 window.open("confirma_criar_usuario.htm","","width=600 height=400")
}

function open_manutenir_usuario()
{
 window.open("confirma_manutenir_usuario.htm","","width=600 height=400")
}

function overLink(el)
{
el.style.color="black";
el.style.textDecoration="underline";
el.style.cursor="hand";
}
