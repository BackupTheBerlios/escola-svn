if ((navigator.appVersion.indexOf("4.")== 0) || (navigator.appVersion.indexOf("5.")== 0))
{
document.write('<STYLE TYPE="text/css">body{margin-top:1px; margin-right:1px; margin-left:1px}.caixamenu{background-color:#E4E7E6 ; font-family:verdana; font-size:8pt}.separadormenu{background-color:#C7CDCB}</style>');


document.write('<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td width="50%" valign="top"></td><td width="25%" valign="top"></td><td width="25%" valign="top"><form> <select name="menulinks" size="1"  onChange="top.location.href=this.form.menulinks.options[this.form.menulinks.selectedIndex].value" class="caixamenu" style="float: right"><option value="index.htm">Selecione a �rea</option><option value="index.htm"></option><option class="separadormenu" value="index.htm">�REAS</option><option value="Aluno/index_aluno.htm">Aluno</option><option value="docente/index_doc.htm">Docente</option><option value="coordenacao/index_coord.htm">Coordena��o</option><option value="administracao/index_adm.htm">Administra��o</option></select> </form></td></tr></table>');
}