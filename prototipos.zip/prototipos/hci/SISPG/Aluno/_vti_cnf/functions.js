vti_encoding:SR|utf8-nl
vti_author:SR|Edison
vti_modifiedby:SR|Edison
vti_timecreated:TR|18 Mar 2003 13:50:55 -0000
vti_timelastmodified:TR|18 Mar 2003 13:50:55 -0000
vti_cacheddtm:TX|18 Mar 2003 13:50:55 -0000
vti_filesize:IR|15235
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|aluno/texto_programas.htm
