vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Jan 2003 19:23:53 -0000
vti_extenderversion:SR|4.0.2.2717
vti_backlinkinfo:VX|aluno/texto_ext_academico_disc_cursadas.htm aluno/texto_ext_academico_disc_restantes.htm aluno/texto_aproveitamento.htm aluno/lista_disciplinas.htm aluno/selecionar_disciplina_top.htm aluno/texto_avaliacao.htm aluno/texto_estagio_docencia.htm aluno/texto_auxilio.htm aluno/texto_requerimentos.htm aluno/texto_matricula.htm aluno/texto_cancelamento.htm aluno/texto_ext_academico_dad_acad.htm aluno/selecionar_disciplina.htm aluno/texto_exame.htm aluno/texto_trancamento.htm aluno/texto_candidato.htm aluno/texto_avaliacao_result.htm aluno/selecionar_disciplina_botton.htm aluno/texto_orientacao.htm aluno/confirma_cancelamento.htm aluno/texto_alteracao.htm aluno/texto_ext_academico_teses.htm aluno/texto_diploma.htm aluno/texto_programas.htm
vti_nexttolasttimemodified:TR|28 Jan 2003 19:03:06 -0000
vti_author:SR|Edison
vti_modifiedby:SR|Edison
vti_timecreated:TR|02 Oct 2002 13:48:06 -0000
