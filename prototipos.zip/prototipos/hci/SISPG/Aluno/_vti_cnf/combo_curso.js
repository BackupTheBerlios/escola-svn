vti_encoding:SR|utf8-nl
vti_author:SR|Edison
vti_modifiedby:SR|Edison A. M. Morais
vti_timecreated:TR|29 Jan 2003 17:12:56 -0000
vti_timelastmodified:TR|31 Jan 2003 12:35:57 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.2717
vti_nexttolasttimemodified:TR|31 Jan 2003 12:35:27 -0000
