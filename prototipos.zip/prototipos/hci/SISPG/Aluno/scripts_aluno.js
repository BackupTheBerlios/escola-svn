function open_disciplina()
{
 window.open("disciplina.htm","","width=700 height=500 scrollbars=yes")
}

function open_curso()
{
 window.open("curso.htm","","width=700 height=500 scrollbars=yes")
}

function open_requerimento()
{
 window.open("requerimento.htm","","width=600 height=400")
}

function open_candidato()
{
 window.open("confirma_candidato.htm","","width=600 height=400")
}

function open_exame()
{
 window.open("confirmacao_exame.htm","","width=600 height=400")
}

function open_trancamento()
{
 window.open("confirma_trancamento.htm","","width=600 height=400")
}

function open_diploma()
{
 window.open("confirma_diploma.htm","","width=600 height=400")
}

function open_tese()
{
 window.open("tese_dissertacao.htm","","width=600 height=400")
}

function open_aproveitamento()
{
 window.open("confirma_aproveitamento.htm","","width=600 height=400")
}

function open_matricula()
{
 window.open("confirma_matricula.htm","","width=600 height=400")
}

function open_selecionar_disciplina()
{
 window.open("selecionar_disciplina.htm","","width=700 height=500 scrollbars=yes")
}

function fechar_janela()
{
 window.close
}

function overLink(el)
{
el.style.color="black";
el.style.textDecoration="underline";
el.style.cursor="hand";
}
