//variavel global usada pela funcao search_usr_name
var jafoi_search_usr_name = new Array();

function setPointer(theRow, thePointerColor, theNormalBgColor)
{
    var theCells = null;

    if (thePointerColor == '' || typeof(theRow.style) == 'undefined') {
        return false;
    }
    if (typeof(document.getElementsByTagName) != 'undefined') {
        theCells = theRow.getElementsByTagName('td');
    }
    else if (typeof(theRow.cells) != 'undefined') {
        theCells = theRow.cells;
    }
    else {
        return false;
    }

    var rowCellsCnt  = theCells.length;
    var currentColor = null;
    var newColor     = null;
    // Opera does not return valid values with "getAttribute"
    if (typeof(window.opera) == 'undefined'
        && typeof(theCells[0].getAttribute) != 'undefined' && typeof(theCells[0].getAttribute) != 'undefined') {
        currentColor = theCells[0].getAttribute('bgcolor');
        newColor     = (currentColor.toLowerCase() == thePointerColor.toLowerCase())
                     ? theNormalBgColor
                     : thePointerColor;
        for (var c = 0; c < rowCellsCnt; c++) {
            theCells[c].setAttribute('bgcolor', newColor, 0);
        } // end for
    }
    else {
        currentColor = theCells[0].style.backgroundColor;
        newColor     = (currentColor.toLowerCase() == thePointerColor.toLowerCase())
                     ? theNormalBgColor
                     : thePointerColor;
        for (var c = 0; c < rowCellsCnt; c++) {
            theCells[c].style.backgroundColor = newColor;
        }
    }

    return true;
} // end of the 'setPointer()' function

function abre_janela(str_url, str_nome, srt_valores)
{
	var nova_janela = false;
	if(str_url)
		nova_janela = window.open(str_url, str_nome, srt_valores);
}

//funcao que deixa marcar somente um checkbox
//usado com as habilidades
function marca_so_um(campo)
{
	var campos = new Object;
	if(campo.form)
		campos = eval("document." + campo.form.name + "[\"" + campo.name + "\"]");
	else
	{
		if(document.all)
			campos = eval("document.all" + "[\"" + campo.name + "\"]");
		else
			campos = eval("document.formulario[\"" + campo.name + "\"]");
	}
	for(aux = 0; aux < campos.length; aux++)
	{
		if(campos[aux].checked && campos[aux] != campo)
			campos[aux].checked = false;
	}
}

function wordCounter(field, countfield, maxlimit) 
{
	wordcounter=0;
	for (x=0;x<field.value.length;x++) 
	{
		if (field.value.charAt(x) == " " && field.value.charAt(x-1) != " ")
			wordcounter++;
		
		if (wordcounter > 250) 
			field.value = field.value.substring(0, x);
		else
			countfield.value = maxlimit - wordcounter;
	}
}
function textCounter(field, countfield, maxlimit)
{
	if(field.value.length > maxlimit)
		field.value = field.value.substring(0, maxlimit);
	else
		countfield.value = maxlimit - field.value.length;
}

function confirm_box(texto)
{
	return confirm(texto);
}

//funcoes para inicializar o formulario
function inicializar()
{
	//minicurriculo
	var campo_atual = document.formulario['cur[minicurriculo]'];
	if(campo_atual.form.remLentext)
		textCounter(campo_atual, campo_atual.form.remLentext, 500);

	var envia_para = document.formulario.envia_para.value;
	if(envia_para)
	{
		var objeto = eval("document.formulario[\""+envia_para+"\"]");
		if(objeto)
			objeto.focus();
	}
}

function gra_muda_ordem(valor_1, valor_2, obj_form)
{
	var objeto = new Array(2);
	objeto[0] = new Array(8);
	objeto[1] = new Array(8);

	//grava os objetos da primeira numa temporaria
	objeto[0][0] = obj_form["cur_gra[nivelg_id]["+valor_1+"]"];//select
	objeto[0][1] = obj_form["cur_gra[curso_string]["+valor_1+"]"];//text
	objeto[0][2] = obj_form["cur_gra[data_inicio][mes]["+valor_1+"]"];//select
	objeto[0][3] = obj_form["cur_gra[data_inicio][ano]["+valor_1+"]"];//select
	objeto[0][4] = obj_form["cur_gra[data_termino][mes]["+valor_1+"]"];//select
	objeto[0][5] = obj_form["cur_gra[data_termino][ano]["+valor_1+"]"];//select
	objeto[0][6] = obj_form["cur_gra[ano_atual]["+valor_1+"]"];//select
	objeto[0][7] = obj_form["cur_gra[instituicao]["+valor_1+"]"];//text

	//grava os objetos da segunda numa temporaria
	objeto[1][0] = obj_form["cur_gra[nivelg_id]["+valor_2+"]"];//select
	objeto[1][1] = obj_form["cur_gra[curso_string]["+valor_2+"]"];//text
	objeto[1][2] = obj_form["cur_gra[data_inicio][mes]["+valor_2+"]"];//select
	objeto[1][3] = obj_form["cur_gra[data_inicio][ano]["+valor_2+"]"];//select
	objeto[1][4] = obj_form["cur_gra[data_termino][mes]["+valor_2+"]"];//select
	objeto[1][5] = obj_form["cur_gra[data_termino][ano]["+valor_2+"]"];//select
	objeto[1][6] = obj_form["cur_gra[ano_atual]["+valor_2+"]"];//select
	objeto[1][7] = obj_form["cur_gra[instituicao]["+valor_2+"]"];//text

	//faz a troca
	troca(objeto);
}

function exp_muda_ordem(valor_1, valor_2, obj_form)
{
	var objeto = new Array(2);
	objeto[0] = new Array(8);
	objeto[1] = new Array(8);

	//grava os objetos da primeira numa temporaria
	objeto[0][0] = obj_form["cur_exp[atual]["+valor_1+"]"];//checked
	objeto[0][1] = obj_form["cur_exp[empresa]["+valor_1+"]"];//text
	objeto[0][2] = obj_form["cur_exp[data_entrada][mes]["+valor_1+"]"];//select
	objeto[0][3] = obj_form["cur_exp[data_entrada][ano]["+valor_1+"]"];//select
	objeto[0][4] = obj_form["cur_exp[data_saida][mes]["+valor_1+"]"];//select
	objeto[0][5] = obj_form["cur_exp[data_saida][ano]["+valor_1+"]"];//select
	objeto[0][6] = obj_form["cur_exp[cargo]["+valor_1+"]"];//text
	objeto[0][7] = obj_form["cur_exp[descricao]["+valor_1+"]"];//text

	//grava os objetos da segunda numa temporaria
	objeto[1][0] = obj_form["cur_exp[atual]["+valor_2+"]"];//checked
	objeto[1][1] = obj_form["cur_exp[empresa]["+valor_2+"]"];//text
	objeto[1][2] = obj_form["cur_exp[data_entrada][mes]["+valor_2+"]"];//select
	objeto[1][3] = obj_form["cur_exp[data_entrada][ano]["+valor_2+"]"];//select
	objeto[1][4] = obj_form["cur_exp[data_saida][mes]["+valor_2+"]"];//select
	objeto[1][5] = obj_form["cur_exp[data_saida][ano]["+valor_2+"]"];//select
	objeto[1][6] = obj_form["cur_exp[cargo]["+valor_2+"]"];//text
	objeto[1][7] = obj_form["cur_exp[descricao]["+valor_2+"]"];//text

	//faz a troca
	troca(objeto);
}

//objeto deve ser array[2][x]
//a funcao identifica o tipo do objeto - select-one ou text ou checkbox
function troca(objeto)
{
	var temp = new Array(objeto[0].length);
	var disabled = new Array(objeto[0].length);

	//grava a primeira numa temporaria
	for(x = 0; x < objeto[0].length; x++)
	{
		if(objeto[0][x].type == "select-one")
			temp[x] = objeto[0][x].selectedIndex;
		else if(objeto[0][x].type == "checkbox" || objeto[0][x].type == "radio")
			temp[x] = objeto[0][x].checked;
		else
			temp[x] = objeto[0][x].value;

		//esta desabilitado?
		disabled[x] = objeto[0][x].disabled;
	}
	//grava os dados da segunda na primeira
	for(x = 0; x < objeto[0].length; x++)
	{
		if(objeto[0][x].type == "select-one")
		{
			if(objeto[1][x].type == "select-one")
				objeto[0][x].selectedIndex = objeto[1][x].selectedIndex;
		}
		else if(objeto[0][x].type == "checkbox" || objeto[1][x].type == "radio")
		{
			if(objeto[1][x].type == "checkbox" || objeto[1][x].type == "radio")
				objeto[0][x].checked = objeto[1][x].checked;
		}
		else
		{
			objeto[0][x].value = objeto[1][x].value;
		}

		//esta desabilitado?
		objeto[0][x].disabled = objeto[1][x].disabled;
	}
	//grava os dados da temporaria na primeira
	for(x = 0; x < temp.length; x++)
	{
		if(objeto[1][x].type == "select-one")
			objeto[1][x].selectedIndex = temp[x];
		else if(objeto[1][x].type == "checkbox" || objeto[1][x].type == "radio")
			objeto[1][x].checked = temp[x];
		else
			objeto[1][x].value = temp[x];

		//esta desabilitado?
		objeto[1][x].disabled = disabled[x];
	}
}
//funcoes para modificar o campo envia_para
function envia_para_change(valor)
{
	var envia_para = document.formulario.envia_para;
	if(envia_para)
		envia_para.value = valor;
}

function disable_exp_data_saida(campo, exp_x)
{
	campo.form["cur_exp[data_saida][mes]["+exp_x+"]"].disabled = campo.checked;
	campo.form["cur_exp[data_saida][ano]["+exp_x+"]"].disabled = campo.checked;
} 


function muda_valor_pai_filho(campo, campo_filho)
{
	var campo_marcados = tamanho(campo);
	var campo_filho_marcados = tamanho(campo_filho);

//alert("campo="+campo_marcados+"\nfilho="+campo_filho_marcados);
	if(campo_marcados && campo_filho_marcados)
	{
		muda_valor(campo_filho, false, false, true);
	}
	else if(!campo_marcados && !campo_filho_marcados)
	{
		muda_valor(campo, false, false, true);
		muda_valor(campo, false, true, true);
		muda_valor(campo_filho, false, true, true);
	}
}

//se numero_para_desmarcar < 0, limpa tudo
function muda_valor(campo, numero_para_desmarcar, valor, limpa_tudo)
{
	var desmarcado = false;
	if(campo.type)
	{
		switch(campo.type)
		{
			case "select-one":
			case "select-multiple":
				for(i = campo.length - 1; i >= 0; i--)
				{
					if(!limpa_tudo && desmarcado >= numero_para_desmarcar)
						break;
					if(campo.options[i].selected)
					{
						campo.options[i].selected = valor;
						desmarcado++;
					}
				}
				break;
			case "radio"://nao tem type
			case "checkbox":
				desmarcado = tamanho(campo);
				campo.checked = valor;
				break;
			case "textarea":
			case "text":
			case "hidden":
				if(limpa_tudo)
				{
					desmarcado = tamanho(campo);
					campo.value = "";
				}
				else
				{
					for(i = campo.value.length - 1; i >= 0; i--)
					{
						if(desmarcado >= numero_para_desmarcar)
							break;
						campo.value[i] = "";
						desmarcado++;
					}
				}
				break;
		}
	}//if type
	else if(campo.length)
	{
		if(campo[0])//radio
		{
			for(i = campo.length - 1; i >= 0; i--)
			{
				if(numero_para_desmarcar > 0 && desmarcado >= numero_para_desmarcar)
					break;
				campo[i] = valor;
				desmarcado++;
			}
		}
	}//if type
	return desmarcado;
}

function tamanho(campo)
{
	var marcado = 0;
	if(!campo)
		return marcado;
	
	if(campo.type)
	{
		switch(campo.type)
		{
			case "select-one":
			case "select-multiple":
				for(i = 0; i < campo.length; i++)
				{
					if(campo.options[i].selected)
						marcado++;
				}
				break;
			case "radio"://radio nao tem campo.type
				for(i = 0; i < campo.length; i++)
				{
					if(campo[i].checked)
						marcado++;
				}
				break;
			case "checkbox":
				marcado = campo.checked;
				break;
			case "textarea":
			case "text":
			case "hidden":
				marcado = campo.value.length;
				break;
		}
	}
	else if(campo.length)
	{
		if(campo[0])//radio
		{
			for(i = 0; i < campo.length; i++)
			{
				if(campo[i].checked)
					marcado++;
			}
		}
/*
		else if(campo.options[0])//select
		{
			for(i = 0; i < campo.length; i++)
			{
				if(campo.options[i].selected)
					marcado++;
			}
		}
*/
	}
	return marcado;
}

//para habilidades antiga
function desmarca_hab_filhos(campo)
{
	var filho_obj = campo.form["cur_hab["+campo.value+"]"]
	//se o estiver checkado..
	if(campo.checked)
	{
		//verifica se tem algum filho checkado, senao desmarca o pai
//		if(tamanho(filho_obj) < 1)
//			campo.checked = false;
	}
	else
	{
		//se o pai nao estiver checkado, desmarca os filhos
		for(i = 0; i < filho_obj.length; i++)
			filho_obj[i].checked = false;
	}
}
function marca_hab_pai(campo)
{
	if(campo.hab_pai_id)
	{
		var pai_obj = campo.form["cur_hab_pai["+campo.hab_pai_id+"]"]
		pai_obj.checked = true;
	}
}

function reload(formulario)
{
//	var mensagem = "Esta p�gina ser� ecarregada. Pressiona ok e aguarde.";
//	alert(mensagem);
	formulario.submit();

//	var mensagem = "Aten��o! Esta p�gina ser� ecarregada. Continuar?";
//	if(confirm_box(mensagem))
//	{
//		formulario.submit();
//		return true;
//	}
//	return false;
	
}

function search_usr_name(theform, field2search, field_name)
{
	//verfifica se campo tem algum valor
	if(!field2search.value)
		return true;

	//verfifica se campo ja foi verificado
	for(aux = 0; aux < jafoi_search_usr_name.length; aux++)
		if(jafoi_search_usr_name[aux] == field2search)
			return true;

	//campos
	var use_personalizado_field = theform["cur[use_personalizado]"];
	//o campo use personalizado pode ser radio ou hidden
	if(use_personalizado_field[0])//se for radio
	{
		for(aux = 0; aux < use_personalizado_field.length; aux++)
		{
			if(use_personalizado_field[aux].checked)
			{
				use_personalizado_field = use_personalizado_field[aux];
				break;
			}
		}
	}
	if(use_personalizado_field.value != 0)//personalizado
	{
		//quando for persionalizada, nao existe o campo conf. moderada.
		//por isso, o campo completa fica com key 1 no array
		//para nao mudar muito o codigo, fazer:
		//confidencial_moderada_field = confidencial_completa_field
		var confidencial_moderada_field = theform["cur[confidencial]"][1];
		var confidencial_completa_field = theform["cur[confidencial]"][1];
	}
	else
	{
		var confidencial_moderada_field = theform["cur[confidencial]"][1];
		var confidencial_completa_field = theform["cur[confidencial]"][2];
	}
	var nome_field = theform["usr[nome]"];

	// Se algum dos campos do fomul�rio n�o existir, retorna "false"
	if(!field2search || !use_personalizado_field ||!confidencial_moderada_field || !confidencial_completa_field || !nome_field)
		return false;

	//mensagem de erro
	if(confidencial_completa_field.checked == true)
		var texto = "Voc� selecionou confidencialidade Completa para o seu curr�culo.";
	else if(confidencial_moderada_field.checked == true)
		var texto = "Voc� selecionou confidencialidade Moderada para o seu curr�culo.";
	texto += "\nNo entanto, voc� escreveu o seu nome no campo "+field_name+".\nPara preservar a confidencialidade de seu curr�culo retire seu nome do campo "+field_name+".";

	//coloca em lower case
	field2search_vl = field2search.value.toLowerCase();
	nome_field_vl = nome_field.value.toLowerCase();
	if(confidencial_moderada_field.checked == true || confidencial_completa_field.checked == true)
	{
		//campo do personalizado
		if(field2search_vl.match(nome_field_vl))
		{
			alert(texto);
			//coloca o nome do campo na variavel global, para nao mostrar
			//mais a mensagem para o mesmo campo.
			jafoi_search_usr_name[jafoi_search_usr_name.length] = field2search;
		}
	}
	return true;
}

function abrir_procura_de_ramos(perfil_id)
{
	var w = window.open("procurar_ramo.php?cur[perfil_id]="+perfil_id, "_blank", "width=450,height=80,left=30,top=120,scrollbars=yes")
	w.focus();
}

//abre a janela para verificar se o cliente ja foi cliente da catho...
var campos_verificados = new Array();
function verifica_cliente(campo)
{
	if(campo.value != "")
	{
		//verifica se ja abriu para este mesmo campo e valor
		for(x = 0; x < campos_verificados.length; x++)
		{
			if(campos_verificados[x][0] == campo.name)
			{
				if(campos_verificados[x][1] == campo.value)
					return false;
			}
		}
	}
	else
		return false;

	var ultimo_registro_na_campos_verificados = campos_verificados.length;
	//cadastra o campo e o valor para nao abrir de novo
	campos_verificados[ultimo_registro_na_campos_verificados] = new Array(2);
	campos_verificados[ultimo_registro_na_campos_verificados][0] = campo.name;
	campos_verificados[ultimo_registro_na_campos_verificados][1] = campo.value;

	//reload no iframe para procurar o cliente ou para abrir o popup
	document.all.iframe_procura.src = "procura_cliente.php?"+campo.name+"="+campo.value;
	return true;
}