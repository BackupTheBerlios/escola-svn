if ((navigator.appVersion.indexOf("4.")== 0) || (navigator.appVersion.indexOf("5.")== 0))
{
document.write('<STYLE TYPE="text/css">body{margin-top:1px; margin-right:1px; margin-left:1px}.caixamenu{background-color:#E4E7E6 ; font-family:verdana; font-size:8pt}.separadormenu{background-color:#C7CDCB}</style>');


document.write('<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td width="50%" valign="top"></td><td width="25%" valign="top"></td><td width="25%" valign="top"><form> <select name="menulinks" size="1"  onChange="top.location.href=this.form.menulinks.options[this.form.menulinks.selectedIndex].value" class="caixamenu" style="float: left"><option value="index_aluno.htm">Selecione o Curso</option><option value="index_aluno.htm">Especializ. em Redes</option><option value="index_aluno1.htm">Mestrado em APSI</option></select> </form></td></tr></table>');
}