vti_encoding:SR|utf8-nl
vti_author:SR|Edison
vti_modifiedby:SR|Edison
vti_timecreated:TR|29 Jan 2003 17:12:56 -0000
vti_timelastmodified:TR|19 Feb 2002 18:08:05 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.5322
vti_nexttolasttimemodified:TR|19 Feb 2002 17:51:18 -0000
vti_filesize:IR|1102
vti_cacheddtm:TX|19 Feb 2002 18:08:05 -0000
