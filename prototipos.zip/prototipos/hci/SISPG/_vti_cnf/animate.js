vti_encoding:SR|utf8-nl
vti_author:SR|Edison
vti_modifiedby:SR|Edison
vti_timecreated:TR|25 Sep 2002 12:52:11 -0000
vti_timelastmodified:TR|25 Sep 2002 12:52:11 -0000
vti_backlinkinfo:VX|inicio_old.htm titulo.htm titulo1.htm
vti_extenderversion:SR|4.0.2.2717
